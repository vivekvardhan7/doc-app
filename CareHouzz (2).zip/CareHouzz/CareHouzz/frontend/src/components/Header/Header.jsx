import React, { useEffect, useRef, useContext, useState } from 'react';
import logo from '../../assets/images/logo.png';
import { Link, NavLink } from 'react-router-dom';
import { BiMenu, BiChat, BiGlobe, BiX, BiSend } from 'react-icons/bi';
import { authContext } from '../../context/AuthContext';

const navLinks = [
  { path: '/home', display: 'Home' },
  { path: '/doctors', display: 'Find a Doctor' },
  { path: '/services', display: 'Services' },
  { path: '/contact', display: 'Contact' },
];

const Header = () => {
  const headerRef = useRef(null);
  const menuRef = useRef(null);
  const { user, role, token } = useContext(authContext);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [language, setLanguage] = useState('English');
  const [message, setMessage] = useState('');
  const [chatMessages, setChatMessages] = useState([]);

  const handleStickyHeader = () => {
    window.addEventListener('scroll', () => {
      if (
        document.body.scrollTop > 80 ||
        document.documentElement.scrollTop > 80
      ) {
        headerRef.current.classList.add('sticky__header');
      } else {
        headerRef.current.classList.remove('sticky__header');
      }
    });
  };

  useEffect(() => {
    handleStickyHeader();
    return () => window.removeEventListener('scroll', handleStickyHeader);
  });

  const toggleMenu = () => {
    menuRef.current.classList.toggle('show__menu');
  };

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  const handleSendMessage = () => {
    if (message.trim()) {
      setChatMessages([...chatMessages, { text: message, language }]);
      setMessage('');
    }
  };

  return (
    <header className="header flex items-center" ref={headerRef}>
      <div className="container">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div>
            <img src={logo} alt="Logo" className="w-[185px] h-auto" />
          </div>

          {/* Menu */}
          <div className="navigation hidden md:flex" ref={menuRef}>
            <ul className="menu flex items-center gap-[2.7rem]">
              {navLinks.map((link, index) => (
                <li key={index}>
                  <NavLink
                    to={link.path}
                    className={({ isActive }) =>
                      isActive
                        ? 'text-primaryColor text-[16px] leading-7 font-[600]'
                        : 'text-textColor text-[16px] leading-7 font-[500] hover:text-primaryColor'
                    }
                  >
                    {link.display}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>

          {/* Right-side: Profile/Login, Language Selector */}
          <div className="flex items-center gap-4">
            {/* User Profile or Login */}
            {user && token ? (
              <div>
                <Link to={`${role === 'doctor' ? '/doctors/profile/me' : '/users/profile/me'}`}>
                  <figure className="w-[35px] h-[35px] rounded-full overflow-hidden">
                    <img src={user?.photo} className="w-full h-full object-cover" alt="User" />
                  </figure>
                </Link>
              </div>
            ) : (
              <Link to="/login">
                <button className="bg-primaryColor py-2 px-6 text-white font-[600] h-[44px] flex items-center justify-center rounded-[50px] transition duration-300 hover:bg-blue-700">
                  Login
                </button>
              </Link>
            )}

            {/* Language Selector */}
            <div className="relative group">
              <BiGlobe className="w-6 h-6 text-primaryColor cursor-pointer" />
              <ul className="absolute right-0 mt-2 w-[150px] bg-white shadow-lg rounded-lg hidden group-hover:block">
                <li
                  className="p-2 hover:bg-primaryColor hover:text-white cursor-pointer transition duration-300"
                  onClick={() => setLanguage('English')}
                >
                  English
                </li>
                <li
                  className="p-2 hover:bg-primaryColor hover:text-white cursor-pointer transition duration-300"
                  onClick={() => setLanguage('తెలుగు')}
                >
                  తెలుగు
                </li>
                <li
                  className="p-2 hover:bg-primaryColor hover:text-white cursor-pointer transition duration-300"
                  onClick={() => setLanguage('हिन्दी')}
                >
                  हिन्दी
                </li>
              </ul>
            </div>

            {/* Mobile Menu Icon */}
            <span className="md:hidden" onClick={toggleMenu}>
              <BiMenu className="w-6 h-6 cursor-pointer text-primaryColor" />
            </span>
          </div>
        </div>
      </div>

      {/* Chatbot Icon */}
      <div className="fixed bottom-4 right-4 z-50">
        <div className="relative">
          <BiChat
            className="w-10 h-10 bg-primaryColor text-white p-2 rounded-full cursor-pointer shadow-lg"
            onClick={toggleChat}
          />
          {isChatOpen && (
            <div className="absolute bottom-[70px] right-0 w-[300px] h-[400px] bg-white shadow-lg rounded-lg p-4 flex flex-col">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-primaryColor">Chatbot</h3>
                <BiX
                  className="w-6 h-6 cursor-pointer text-primaryColor"
                  onClick={toggleChat}
                />
              </div>
              <div className="flex-grow overflow-y-auto mb-4">
                {chatMessages.map((msg, index) => (
                  <p key={index} className="text-sm text-gray-600">
                    <strong>{msg.language}:</strong> {msg.text}
                  </p>
                ))}
              </div>
              <div className="flex items-center border-t pt-2">
                <input
                  type="text"
                  className="flex-grow px-4 py-2 border border-gray-300 rounded-lg focus:outline-none"
                  placeholder="Type your message..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                />
                <button
                  className="ml-2 bg-primaryColor text-white px-4 py-2 rounded-lg flex items-center transition duration-300 hover:bg-blue-700"
                  onClick={handleSendMessage}
                >
                  <BiSend className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
