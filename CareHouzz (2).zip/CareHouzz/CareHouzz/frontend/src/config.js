export const BASE_URL = 'http://localhost:5050/api/v1'
export const token = localStorage.getItem('token')